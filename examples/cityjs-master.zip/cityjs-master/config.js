// This is needed for brunch generate
exports.config = {
	files: {}
};